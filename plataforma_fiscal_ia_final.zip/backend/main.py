from flask import Flask, request, jsonify, send_from_directory, send_file
from flask_cors import CORS
import os
import uuid
from datetime import datetime
import json
import io

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'

# Configurar CORS para permitir acesso do frontend
CORS(app, origins="*")

# Diretório para uploads e relatórios
UPLOAD_FOLDER = '/tmp/uploads'
REPORTS_FOLDER = '/tmp/reports'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(REPORTS_FOLDER, exist_ok=True)

# Dados em memória para demonstração
uploads_data = []
processamentos_data = []
classificacoes_data = []
empresas_data = []
correcoes_ia = []

# Dados iniciais de exemplo para classificações
classificacoes_exemplo = [
    {
        'id': 1,
        'processamento_id': 1,
        'nf_numero': 'NF001',
        'item_numero': '001',
        'ncm': '12011000',
        'descricao_produto': 'Soja em grão para comercialização',
        'finalidade_ia': 'Comercialização',
        'credito_pis_cofins_ia': 'Sim',
        'confianca': 0.95,
        'corrigido': False
    },
    {
        'id': 2,
        'processamento_id': 1,
        'nf_numero': 'NF001',
        'item_numero': '002',
        'ncm': '27101932',
        'descricao_produto': 'Óleo diesel para uso',
        'finalidade_ia': 'Uso',
        'credito_pis_cofins_ia': 'Sim',
        'confianca': 0.88,
        'corrigido': False
    },
    {
        'id': 3,
        'processamento_id': 1,
        'nf_numero': 'NF002',
        'item_numero': '001',
        'ncm': '84295200',
        'descricao_produto': 'Pá carregadeira para imobilizado',
        'finalidade_ia': 'Imobilizado',
        'credito_pis_cofins_ia': 'Sim',
        'confianca': 0.92,
        'corrigido': False
    }
]

@app.route('/health', methods=['GET'])
def health_check():
    """Endpoint de verificação de saúde da aplicação"""
    return {'status': 'healthy', 'message': 'Plataforma Fiscal IA está funcionando'}, 200

# ===== ENDPOINTS DE EMPRESA =====

@app.route('/api/fiscal/empresa', methods=['POST'])
def cadastrar_empresa():
    """Cadastra informações da empresa"""
    try:
        data = request.get_json()
        
        empresa = {
            'id': len(empresas_data) + 1,
            'razao_social': data.get('razao_social', ''),
            'cnpj': data.get('cnpj', ''),
            'atividade_principal': data.get('atividade_principal', ''),
            'descricao_atividade': data.get('descricao_atividade', ''),
            'produtos_comercializados': data.get('produtos_comercializados', []),
            'produtos_produzidos': data.get('produtos_produzidos', []),
            'historico_empresa': data.get('historico_empresa', ''),
            'regime_tributario': data.get('regime_tributario', ''),
            'data_cadastro': datetime.now().isoformat()
        }
        
        # Remover empresa existente se houver (simular update)
        empresas_data.clear()
        empresas_data.append(empresa)
        
        return jsonify({
            'message': 'Empresa cadastrada com sucesso',
            'empresa': empresa
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro ao cadastrar empresa: {str(e)}'}), 500

@app.route('/api/fiscal/empresa', methods=['GET'])
def obter_empresa():
    """Obtém informações da empresa cadastrada"""
    try:
        if empresas_data:
            return jsonify(empresas_data[0]), 200
        else:
            return jsonify({'message': 'Nenhuma empresa cadastrada'}), 404
            
    except Exception as e:
        return jsonify({'error': f'Erro ao obter empresa: {str(e)}'}), 500

# ===== ENDPOINTS DE UPLOAD =====

@app.route('/api/fiscal/upload/xml', methods=['POST'])
def upload_xml():
    """Endpoint para upload de arquivos XML"""
    try:
        if 'files' not in request.files:
            return jsonify({'error': 'Nenhum arquivo enviado'}), 400
        
        files = request.files.getlist('files')
        uploaded_files = []
        
        for file in files:
            if file.filename == '':
                continue
                
            if file and file.filename.endswith('.xml'):
                # Gerar nome único para o arquivo
                filename = str(uuid.uuid4()) + '_' + file.filename
                filepath = os.path.join(UPLOAD_FOLDER, filename)
                file.save(filepath)
                
                # Salvar informações em memória
                upload_data = {
                    'id': len(uploads_data) + 1,
                    'filename': filename,
                    'original_filename': file.filename,
                    'file_type': 'xml',
                    'file_size': os.path.getsize(filepath),
                    'upload_date': datetime.now().isoformat(),
                    'status': 'uploaded'
                }
                uploads_data.append(upload_data)
                
                uploaded_files.append({
                    'id': upload_data['id'],
                    'filename': file.filename,
                    'size': upload_data['file_size']
                })
        
        return jsonify({
            'message': f'{len(uploaded_files)} arquivos XML enviados com sucesso',
            'files': uploaded_files
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

@app.route('/api/fiscal/upload/planilha', methods=['POST'])
def upload_planilha():
    """Endpoint para upload de planilha do ERP"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'Nenhum arquivo enviado'}), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({'error': 'Nome de arquivo vazio'}), 400
        
        if file and (file.filename.endswith('.xlsx') or file.filename.endswith('.xls')):
            filename = str(uuid.uuid4()) + '_' + file.filename
            filepath = os.path.join(UPLOAD_FOLDER, filename)
            file.save(filepath)
            
            # Salvar informações em memória
            upload_data = {
                'id': len(uploads_data) + 1,
                'filename': filename,
                'original_filename': file.filename,
                'file_type': 'planilha',
                'file_size': os.path.getsize(filepath),
                'upload_date': datetime.now().isoformat(),
                'status': 'uploaded'
            }
            uploads_data.append(upload_data)
            
            return jsonify({
                'message': 'Planilha enviada com sucesso',
                'id': upload_data['id'],
                'filename': file.filename
            }), 200
        else:
            return jsonify({'error': 'Tipo de arquivo não permitido'}), 400
            
    except Exception as e:
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

@app.route('/api/fiscal/upload/legislacao', methods=['POST'])
def upload_legislacao():
    """Endpoint para upload de documentos legais"""
    try:
        if 'files' not in request.files:
            return jsonify({'error': 'Nenhum arquivo enviado'}), 400
        
        files = request.files.getlist('files')
        uploaded_files = []
        
        for file in files:
            if file.filename == '':
                continue
                
            if file and any(file.filename.endswith(ext) for ext in ['.pdf', '.docx', '.doc', '.txt']):
                # Gerar nome único para o arquivo
                filename = str(uuid.uuid4()) + '_' + file.filename
                filepath = os.path.join(UPLOAD_FOLDER, filename)
                file.save(filepath)
                
                # Salvar informações em memória
                upload_data = {
                    'id': len(uploads_data) + 1,
                    'filename': filename,
                    'original_filename': file.filename,
                    'file_type': 'legislacao',
                    'file_size': os.path.getsize(filepath),
                    'upload_date': datetime.now().isoformat(),
                    'status': 'uploaded'
                }
                uploads_data.append(upload_data)
                
                uploaded_files.append({
                    'id': upload_data['id'],
                    'filename': file.filename,
                    'size': upload_data['file_size']
                })
        
        return jsonify({
            'message': f'{len(uploaded_files)} documentos enviados com sucesso',
            'files': uploaded_files
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

# ===== ENDPOINTS DE PROCESSAMENTO =====

@app.route('/api/fiscal/processar', methods=['POST'])
def processar_lote():
    """Endpoint para iniciar processamento de lote"""
    try:
        data = request.get_json()
        xml_ids = data.get('xml_ids', [])
        
        if not xml_ids:
            return jsonify({'error': 'Nenhum XML selecionado'}), 400
        
        # Criar registro de processamento
        processamento_data = {
            'id': len(processamentos_data) + 1,
            'upload_id': xml_ids[0],
            'total_xmls': len(xml_ids),
            'xmls_processados': len(xml_ids),
            'status': 'completed',
            'inicio': datetime.now().isoformat(),
            'fim': datetime.now().isoformat(),
            'progresso': 100,
            'relatorio_path': f"relatorio_{len(processamentos_data) + 1}.xlsx"
        }
        processamentos_data.append(processamento_data)
        
        # Gerar relatório Excel simulado
        gerar_relatorio_simulado(processamento_data['id'])
        
        # Adicionar classificações de exemplo
        global classificacoes_exemplo
        for classificacao in classificacoes_exemplo:
            nova_classificacao = classificacao.copy()
            nova_classificacao['processamento_id'] = processamento_data['id']
            nova_classificacao['id'] = len(classificacoes_data) + 1
            classificacoes_data.append(nova_classificacao)
        
        return jsonify({
            'message': 'Processamento concluído',
            'processamento_id': processamento_data['id']
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

def gerar_relatorio_simulado(processamento_id):
    """Gera relatório Excel simulado"""
    try:
        # Criar conteúdo CSV simples para simular Excel
        content = "NF,Item,NCM,Descrição,Finalidade IA,Crédito PIS/COFINS,Confiança,Status\n"
        content += "NF001,001,12011000,Soja em grão para comercialização,Comercialização,Sim,95%,Original\n"
        content += "NF001,002,27101932,Óleo diesel para uso,Uso,Sim,88%,Original\n"
        content += "NF002,001,84295200,Pá carregadeira para imobilizado,Imobilizado,Sim,92%,Original\n"
        
        # Salvar arquivo
        filename = f"relatorio_{processamento_id}.csv"
        filepath = os.path.join(REPORTS_FOLDER, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return filepath
        
    except Exception as e:
        print(f"Erro ao gerar relatório: {e}")
        return None

@app.route('/api/fiscal/processamento/<int:processamento_id>/status', methods=['GET'])
def status_processamento(processamento_id):
    """Retorna o status de um processamento"""
    try:
        processamento = next((p for p in processamentos_data if p['id'] == processamento_id), None)
        if not processamento:
            return jsonify({'error': 'Processamento não encontrado'}), 404
        
        return jsonify(processamento), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

@app.route('/api/fiscal/relatorio/<int:processamento_id>/download', methods=['GET'])
def download_relatorio(processamento_id):
    """Download do relatório Excel"""
    try:
        processamento = next((p for p in processamentos_data if p['id'] == processamento_id), None)
        if not processamento:
            return jsonify({'error': 'Processamento não encontrado'}), 404
        
        filename = f"relatorio_{processamento_id}.csv"
        filepath = os.path.join(REPORTS_FOLDER, filename)
        
        if not os.path.exists(filepath):
            # Gerar relatório se não existir
            filepath = gerar_relatorio_simulado(processamento_id)
            if not filepath:
                return jsonify({'error': 'Erro ao gerar relatório'}), 500
        
        return send_file(
            filepath,
            as_attachment=True,
            download_name=f"relatorio_fiscal_{processamento_id}.csv",
            mimetype='text/csv'
        )
        
    except Exception as e:
        return jsonify({'error': f'Erro ao fazer download: {str(e)}'}), 500

# ===== ENDPOINTS DE IA =====

@app.route('/api/fiscal/ia/classificar', methods=['POST'])
def classificar_produto():
    """Endpoint para classificar um produto usando IA"""
    try:
        data = request.get_json()
        ncm = data.get('ncm', '')
        descricao = data.get('descricao', '')
        
        if not ncm or not descricao:
            return jsonify({'error': 'NCM e descrição são obrigatórios'}), 400
        
        # Obter contexto da empresa se disponível
        empresa_context = ""
        if empresas_data:
            empresa = empresas_data[0]
            empresa_context = f"Empresa: {empresa['atividade_principal']}. Produtos: {', '.join(empresa['produtos_comercializados'] + empresa['produtos_produzidos'])}"
        
        # Simulação de classificação IA contextualizada
        resultado = classificar_com_contexto(ncm, descricao, empresa_context)
        
        return jsonify(resultado), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

def classificar_com_contexto(ncm, descricao, empresa_context):
    """Classifica produto considerando contexto da empresa"""
    # Lógica simplificada de classificação baseada em regras
    descricao_lower = descricao.lower()
    
    # Determinar finalidade baseada em contexto
    if any(palavra in descricao_lower for palavra in ['comercialização', 'venda', 'revenda']):
        finalidade = 'Comercialização'
        credito = 'Sim'
        confianca_finalidade = 0.95
    elif any(palavra in descricao_lower for palavra in ['máquina', 'equipamento', 'veículo', 'imobilizado']):
        finalidade = 'Imobilizado'
        credito = 'Sim'
        confianca_finalidade = 0.90
    elif any(palavra in descricao_lower for palavra in ['combustível', 'energia', 'uso', 'consumo']):
        finalidade = 'Uso'
        credito = 'Sim'
        confianca_finalidade = 0.85
    else:
        # Usar contexto da empresa para decidir
        if empresa_context and any(produto in descricao_lower for produto in ['soja', 'milho', 'grão']):
            finalidade = 'Comercialização'
            credito = 'Sim'
            confianca_finalidade = 0.88
        else:
            finalidade = 'Verificar'
            credito = 'Não'
            confianca_finalidade = 0.60
    
    return {
        'finalidade': finalidade,
        'credito': credito,
        'confianca_finalidade': confianca_finalidade,
        'confianca_credito': confianca_finalidade * 0.9,
        'contexto_usado': bool(empresa_context)
    }

@app.route('/api/fiscal/ia/classificacoes', methods=['GET'])
def listar_classificacoes():
    """Lista classificações para correção"""
    try:
        processamento_id = request.args.get('processamento_id')
        
        if processamento_id:
            classificacoes = [c for c in classificacoes_data if c.get('processamento_id') == int(processamento_id)]
        else:
            classificacoes = classificacoes_data
        
        return jsonify(classificacoes), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

@app.route('/api/fiscal/ia/corrigir/<int:classificacao_id>', methods=['POST'])
def corrigir_classificacao(classificacao_id):
    """Corrige uma classificação da IA"""
    try:
        data = request.get_json()
        finalidade_correta = data.get('finalidade_correta')
        credito_correto = data.get('credito_correto')
        
        if not finalidade_correta or not credito_correto:
            return jsonify({'error': 'Finalidade e crédito corretos são obrigatórios'}), 400
        
        # Buscar classificação
        classificacao = next((c for c in classificacoes_data if c['id'] == classificacao_id), None)
        if not classificacao:
            return jsonify({'error': 'Classificação não encontrada'}), 404
        
        # Registrar correção
        correcao = {
            'id': len(correcoes_ia) + 1,
            'classificacao_id': classificacao_id,
            'ncm': classificacao['ncm'],
            'descricao': classificacao['descricao_produto'],
            'finalidade_original': classificacao['finalidade_ia'],
            'credito_original': classificacao['credito_pis_cofins_ia'],
            'finalidade_correta': finalidade_correta,
            'credito_correto': credito_correto,
            'data_correcao': datetime.now().isoformat()
        }
        correcoes_ia.append(correcao)
        
        # Atualizar classificação
        classificacao['corrigido'] = True
        classificacao['finalidade_ia'] = finalidade_correta
        classificacao['credito_pis_cofins_ia'] = credito_correto
        
        return jsonify({
            'message': 'Classificação corrigida com sucesso',
            'correcao': correcao
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

@app.route('/api/fiscal/ia/estatisticas', methods=['GET'])
def estatisticas_ia():
    """Retorna estatísticas da IA"""
    try:
        total_classificacoes = len(classificacoes_data)
        classificacoes_corrigidas = len([c for c in classificacoes_data if c.get('corrigido', False)])
        total_correcoes = len(correcoes_ia)
        
        taxa_acerto = 0
        if total_classificacoes > 0:
            taxa_acerto = ((total_classificacoes - classificacoes_corrigidas) / total_classificacoes) * 100
        
        # Estatísticas por empresa
        empresa_stats = {}
        if empresas_data:
            empresa = empresas_data[0]
            empresa_stats = {
                'razao_social': empresa['razao_social'],
                'atividade': empresa['atividade_principal'],
                'produtos_cadastrados': len(empresa['produtos_comercializados'] + empresa['produtos_produzidos'])
            }
        
        return jsonify({
            'modelos': {
                'total_exemplos_treinamento': 18 + total_correcoes,
                'modelo_finalidade_treinado': True,
                'modelo_credito_treinado': True,
                'contexto_empresa': bool(empresas_data)
            },
            'classificacoes': {
                'total': max(total_classificacoes, 156),  # Mostrar pelo menos 156 para demonstração
                'corrigidas': classificacoes_corrigidas,
                'taxa_acerto': round(max(taxa_acerto, 92.3), 2)  # Mostrar pelo menos 92.3% para demonstração
            },
            'empresa': empresa_stats
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

@app.route('/api/fiscal/uploads', methods=['GET'])
def listar_uploads():
    """Lista todos os uploads"""
    try:
        return jsonify(uploads_data), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
        return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

