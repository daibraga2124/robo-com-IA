# 🚀 Plataforma Fiscal IA - Backend (FastAPI)

Este repositório contém a API backend da plataforma tributária inteligente com IA.

## ✅ Tecnologias
- Python 3.11
- FastAPI
- Uvicorn
- IA fiscal personalizada (via `agente_fiscal_ia.py`)

## ▶️ Execução local

```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

Acesse: [http://localhost:8000/docs](http://localhost:8000/docs)

## 🌐 Deploy na Render.com (grátis)

1. Crie uma conta em https://render.com
2. Crie um repositório no GitHub com esta pasta `backend/`
3. No painel da Render:
   - New + → Web Service
   - Runtime: **Python 3**
   - Build command: *(deixe em branco)*
   - Start command:
     ```bash
     uvicorn main:app --host 0.0.0.0 --port 10000
     ```
   - Set PORT to `10000` (em environment)
4. Acesse: `https://seu-projeto.onrender.com`