import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog.jsx'
import { Upload, FileText, Brain, Download, CheckCircle, AlertCircle, Clock, Building, Edit, Save, X } from 'lucide-react'
import './App.css'

const API_BASE = 'http://localhost:5000/api/fiscal'

function App() {
  const [uploads, setUploads] = useState([])
  const [processamentos, setProcessamentos] = useState([])
  const [estatisticasIA, setEstatisticasIA] = useState(null)
  const [empresa, setEmpresa] = useState(null)
  const [classificacoes, setClassificacoes] = useState([])
  const [activeTab, setActiveTab] = useState('empresa')
  const [showEmpresaForm, setShowEmpresaForm] = useState(false)
  const [showCorrecaoDialog, setShowCorrecaoDialog] = useState(false)
  const [classificacaoSelecionada, setClassificacaoSelecionada] = useState(null)

  // Estados do formulário de empresa
  const [empresaForm, setEmpresaForm] = useState({
    razao_social: '',
    cnpj: '',
    atividade_principal: '',
    descricao_atividade: '',
    produtos_comercializados: '',
    produtos_produzidos: '',
    historico_empresa: '',
    regime_tributario: ''
  })

  // Estados da correção
  const [correcaoForm, setCorrecaoForm] = useState({
    finalidade_correta: '',
    credito_correto: ''
  })

  useEffect(() => {
    carregarDados()
  }, [])

  const carregarDados = async () => {
    try {
      // Carregar empresa
      const empresaRes = await fetch(`${API_BASE}/empresa`)
      if (empresaRes.ok) {
        const empresaData = await empresaRes.json()
        setEmpresa(empresaData)
        setEmpresaForm({
          ...empresaData,
          produtos_comercializados: empresaData.produtos_comercializados?.join(', ') || '',
          produtos_produzidos: empresaData.produtos_produzidos?.join(', ') || ''
        })
      }

      // Carregar estatísticas
      const statsRes = await fetch(`${API_BASE}/ia/estatisticas`)
      if (statsRes.ok) {
        const statsData = await statsRes.json()
        setEstatisticasIA(statsData)
      }

      // Carregar uploads
      const uploadsRes = await fetch(`${API_BASE}/uploads`)
      if (uploadsRes.ok) {
        const uploadsData = await uploadsRes.json()
        setUploads(uploadsData)
      }

      // Carregar classificações
      const classRes = await fetch(`${API_BASE}/ia/classificacoes`)
      if (classRes.ok) {
        const classData = await classRes.json()
        setClassificacoes(classData)
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error)
    }
  }

  const salvarEmpresa = async () => {
    try {
      const dadosEmpresa = {
        ...empresaForm,
        produtos_comercializados: empresaForm.produtos_comercializados.split(',').map(p => p.trim()).filter(p => p),
        produtos_produzidos: empresaForm.produtos_produzidos.split(',').map(p => p.trim()).filter(p => p)
      }

      const response = await fetch(`${API_BASE}/empresa`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(dadosEmpresa)
      })

      if (response.ok) {
        const result = await response.json()
        setEmpresa(result.empresa)
        setShowEmpresaForm(false)
        carregarDados()
        alert('Empresa cadastrada com sucesso!')
      } else {
        alert('Erro ao cadastrar empresa')
      }
    } catch (error) {
      console.error('Erro ao salvar empresa:', error)
      alert('Erro ao salvar empresa')
    }
  }

  const corrigirClassificacao = async () => {
    try {
      const response = await fetch(`${API_BASE}/ia/corrigir/${classificacaoSelecionada.id}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(correcaoForm)
      })

      if (response.ok) {
        setShowCorrecaoDialog(false)
        setClassificacaoSelecionada(null)
        setCorrecaoForm({ finalidade_correta: '', credito_correto: '' })
        carregarDados()
        alert('Classificação corrigida com sucesso!')
      } else {
        alert('Erro ao corrigir classificação')
      }
    } catch (error) {
      console.error('Erro ao corrigir classificação:', error)
      alert('Erro ao corrigir classificação')
    }
  }

  const handleFileUpload = async (event, type) => {
    const files = Array.from(event.target.files)
    const formData = new FormData()
    
    if (type === 'planilha') {
      formData.append('file', files[0])
    } else {
      files.forEach(file => formData.append('files', file))
    }

    try {
      const endpoint = type === 'planilha' ? 'upload/planilha' : `upload/${type}`
      const response = await fetch(`${API_BASE}/${endpoint}`, {
        method: 'POST',
        body: formData
      })

      if (response.ok) {
        carregarDados()
        alert('Arquivos enviados com sucesso!')
      } else {
        alert('Erro ao enviar arquivos')
      }
    } catch (error) {
      console.error('Erro no upload:', error)
      alert('Erro no upload')
    }
  }

  const startProcessing = async () => {
    const xmlFiles = uploads.filter(u => u.file_type === 'xml')
    if (xmlFiles.length === 0) {
      alert('Selecione pelo menos um arquivo XML para processar')
      return
    }

    try {
      const response = await fetch(`${API_BASE}/processar`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          xml_ids: xmlFiles.map(f => f.id)
        })
      })

      if (response.ok) {
        const result = await response.json()
        setActiveTab('processamento')
        carregarDados()
        alert('Processamento iniciado com sucesso!')
      } else {
        alert('Erro ao iniciar processamento')
      }
    } catch (error) {
      console.error('Erro no processamento:', error)
      alert('Erro no processamento')
    }
  }

  const downloadRelatorio = async (processamentoId) => {
    try {
      const response = await fetch(`${API_BASE}/relatorio/${processamentoId}/download`)
      
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `relatorio_fiscal_${processamentoId}.xlsx`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
      } else {
        alert('Erro ao fazer download do relatório')
      }
    } catch (error) {
      console.error('Erro no download:', error)
      alert('Erro no download')
    }
  }

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'processing': return <Clock className="h-4 w-4 text-blue-500" />
      case 'error': return <AlertCircle className="h-4 w-4 text-red-500" />
      default: return <FileText className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusBadge = (status) => {
    const variants = {
      'uploaded': 'secondary',
      'processing': 'default',
      'completed': 'default',
      'error': 'destructive'
    }
    
    const labels = {
      'uploaded': 'Enviado',
      'processing': 'Processando',
      'completed': 'Concluído',
      'error': 'Erro'
    }

    return <Badge variant={variants[status]}>{labels[status]}</Badge>
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Plataforma Fiscal IA
          </h1>
          <p className="text-lg text-gray-600">
            Sistema Inteligente de Processamento Fiscal com IA Contextualizada
          </p>
        </div>

        {/* Estatísticas da IA */}
        {estatisticasIA && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Brain className="h-5 w-5 text-blue-500" />
                  <div>
                    <p className="text-sm font-medium">Taxa de Acerto IA</p>
                    <p className="text-2xl font-bold text-blue-600">
                      {estatisticasIA.classificacoes.taxa_acerto}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <FileText className="h-5 w-5 text-green-500" />
                  <div>
                    <p className="text-sm font-medium">Classificações</p>
                    <p className="text-2xl font-bold text-green-600">
                      {estatisticasIA.classificacoes.total}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5 text-purple-500" />
                  <div>
                    <p className="text-sm font-medium">Exemplos Treinamento</p>
                    <p className="text-2xl font-bold text-purple-600">
                      {estatisticasIA.modelos.total_exemplos_treinamento}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Building className="h-5 w-5 text-orange-500" />
                  <div>
                    <p className="text-sm font-medium">Empresa Cadastrada</p>
                    <p className="text-2xl font-bold text-orange-600">
                      {empresa ? 'Sim' : 'Não'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Tabs principais */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="empresa">Empresa</TabsTrigger>
            <TabsTrigger value="upload">Upload</TabsTrigger>
            <TabsTrigger value="processamento">Processamento</TabsTrigger>
            <TabsTrigger value="resultados">Resultados</TabsTrigger>
            <TabsTrigger value="ia">Correção IA</TabsTrigger>
          </TabsList>

          {/* Tab Empresa */}
          <TabsContent value="empresa" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center space-x-2">
                      <Building className="h-5 w-5" />
                      <span>Informações da Empresa</span>
                    </CardTitle>
                    <CardDescription>
                      Cadastre informações da empresa para melhorar a precisão da IA
                    </CardDescription>
                  </div>
                  <Button 
                    onClick={() => setShowEmpresaForm(!showEmpresaForm)}
                    variant={empresa ? "outline" : "default"}
                  >
                    {empresa ? <Edit className="h-4 w-4 mr-2" /> : <Building className="h-4 w-4 mr-2" />}
                    {empresa ? 'Editar' : 'Cadastrar'} Empresa
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {empresa && !showEmpresaForm ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="font-medium">Razão Social</Label>
                      <p className="text-gray-700">{empresa.razao_social}</p>
                    </div>
                    <div>
                      <Label className="font-medium">CNPJ</Label>
                      <p className="text-gray-700">{empresa.cnpj}</p>
                    </div>
                    <div>
                      <Label className="font-medium">Atividade Principal</Label>
                      <p className="text-gray-700">{empresa.atividade_principal}</p>
                    </div>
                    <div>
                      <Label className="font-medium">Regime Tributário</Label>
                      <p className="text-gray-700">{empresa.regime_tributario}</p>
                    </div>
                    <div className="md:col-span-2">
                      <Label className="font-medium">Descrição da Atividade</Label>
                      <p className="text-gray-700">{empresa.descricao_atividade}</p>
                    </div>
                    <div>
                      <Label className="font-medium">Produtos Comercializados</Label>
                      <p className="text-gray-700">{empresa.produtos_comercializados?.join(', ')}</p>
                    </div>
                    <div>
                      <Label className="font-medium">Produtos Produzidos</Label>
                      <p className="text-gray-700">{empresa.produtos_produzidos?.join(', ')}</p>
                    </div>
                    <div className="md:col-span-2">
                      <Label className="font-medium">Histórico da Empresa</Label>
                      <p className="text-gray-700">{empresa.historico_empresa}</p>
                    </div>
                  </div>
                ) : showEmpresaForm ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="razao_social">Razão Social *</Label>
                        <Input
                          id="razao_social"
                          value={empresaForm.razao_social}
                          onChange={(e) => setEmpresaForm({...empresaForm, razao_social: e.target.value})}
                          placeholder="Nome da empresa"
                        />
                      </div>
                      <div>
                        <Label htmlFor="cnpj">CNPJ *</Label>
                        <Input
                          id="cnpj"
                          value={empresaForm.cnpj}
                          onChange={(e) => setEmpresaForm({...empresaForm, cnpj: e.target.value})}
                          placeholder="00.000.000/0000-00"
                        />
                      </div>
                      <div>
                        <Label htmlFor="atividade_principal">Atividade Principal *</Label>
                        <Input
                          id="atividade_principal"
                          value={empresaForm.atividade_principal}
                          onChange={(e) => setEmpresaForm({...empresaForm, atividade_principal: e.target.value})}
                          placeholder="Ex: Comércio de grãos"
                        />
                      </div>
                      <div>
                        <Label htmlFor="regime_tributario">Regime Tributário</Label>
                        <Select 
                          value={empresaForm.regime_tributario} 
                          onValueChange={(value) => setEmpresaForm({...empresaForm, regime_tributario: value})}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o regime" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="simples">Simples Nacional</SelectItem>
                            <SelectItem value="presumido">Lucro Presumido</SelectItem>
                            <SelectItem value="real">Lucro Real</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="descricao_atividade">Descrição da Atividade</Label>
                      <Textarea
                        id="descricao_atividade"
                        value={empresaForm.descricao_atividade}
                        onChange={(e) => setEmpresaForm({...empresaForm, descricao_atividade: e.target.value})}
                        placeholder="Descreva detalhadamente as atividades da empresa..."
                        rows={3}
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="produtos_comercializados">Produtos Comercializados</Label>
                        <Textarea
                          id="produtos_comercializados"
                          value={empresaForm.produtos_comercializados}
                          onChange={(e) => setEmpresaForm({...empresaForm, produtos_comercializados: e.target.value})}
                          placeholder="Soja, milho, trigo (separados por vírgula)"
                          rows={3}
                        />
                      </div>
                      <div>
                        <Label htmlFor="produtos_produzidos">Produtos Produzidos</Label>
                        <Textarea
                          id="produtos_produzidos"
                          value={empresaForm.produtos_produzidos}
                          onChange={(e) => setEmpresaForm({...empresaForm, produtos_produzidos: e.target.value})}
                          placeholder="Ração, farelo, óleo (separados por vírgula)"
                          rows={3}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="historico_empresa">Histórico da Empresa</Label>
                      <Textarea
                        id="historico_empresa"
                        value={empresaForm.historico_empresa}
                        onChange={(e) => setEmpresaForm({...empresaForm, historico_empresa: e.target.value})}
                        placeholder="Conte a história da empresa, principais marcos, mudanças de atividade..."
                        rows={4}
                      />
                    </div>
                    
                    <div className="flex space-x-2">
                      <Button onClick={salvarEmpresa}>
                        <Save className="h-4 w-4 mr-2" />
                        Salvar Empresa
                      </Button>
                      <Button variant="outline" onClick={() => setShowEmpresaForm(false)}>
                        <X className="h-4 w-4 mr-2" />
                        Cancelar
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Building className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                    <h3 className="text-lg font-medium mb-2">Nenhuma empresa cadastrada</h3>
                    <p className="text-gray-600 mb-4">
                      Cadastre informações da empresa para que a IA possa fazer classificações mais precisas
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab Upload */}
          <TabsContent value="upload" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Upload XMLs */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <FileText className="h-5 w-5" />
                    <span>Arquivos XML</span>
                  </CardTitle>
                  <CardDescription>
                    Envie os arquivos XML das Notas Fiscais Eletrônicas
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                    <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                    <p className="text-sm text-gray-600 mb-2">
                      Clique para selecionar ou arraste arquivos XML
                    </p>
                    <input
                      type="file"
                      multiple
                      accept=".xml"
                      onChange={(e) => handleFileUpload(e, 'xml')}
                      className="hidden"
                      id="xml-upload"
                    />
                    <Button 
                      onClick={() => document.getElementById('xml-upload').click()}
                      variant="outline"
                    >
                      Selecionar XMLs
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Upload Planilha */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <FileText className="h-5 w-5" />
                    <span>Planilha ERP</span>
                  </CardTitle>
                  <CardDescription>
                    Envie a planilha do sistema ERP para comparação
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-green-400 transition-colors">
                    <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                    <p className="text-sm text-gray-600 mb-2">
                      Selecione a planilha do ERP
                    </p>
                    <input
                      type="file"
                      accept=".xlsx,.xls"
                      onChange={(e) => handleFileUpload(e, 'planilha')}
                      className="hidden"
                      id="planilha-upload"
                    />
                    <Button 
                      onClick={() => document.getElementById('planilha-upload').click()}
                      variant="outline"
                    >
                      Selecionar Planilha
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Upload Legislação */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Brain className="h-5 w-5" />
                    <span>Documentos Legais</span>
                  </CardTitle>
                  <CardDescription>
                    Envie documentos de legislação para treinar a IA
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-purple-400 transition-colors">
                    <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                    <p className="text-sm text-gray-600 mb-2">
                      PDFs, Word ou documentos de texto
                    </p>
                    <input
                      type="file"
                      multiple
                      accept=".pdf,.docx,.doc,.txt"
                      onChange={(e) => handleFileUpload(e, 'legislacao')}
                      className="hidden"
                      id="legislacao-upload"
                    />
                    <Button 
                      onClick={() => document.getElementById('legislacao-upload').click()}
                      variant="outline"
                    >
                      Selecionar Documentos
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Lista de arquivos enviados */}
            {uploads.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Arquivos Enviados</CardTitle>
                  <CardDescription>
                    Lista de todos os arquivos enviados para processamento
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {uploads.map((upload) => (
                      <div key={upload.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <FileText className="h-4 w-4 text-gray-500" />
                          <div>
                            <p className="font-medium">{upload.original_filename}</p>
                            <p className="text-sm text-gray-500">
                              {upload.file_type.toUpperCase()} • {formatFileSize(upload.file_size)}
                            </p>
                          </div>
                        </div>
                        {getStatusBadge(upload.status)}
                      </div>
                    ))}
                  </div>
                  
                  {uploads.filter(u => u.file_type === 'xml').length > 0 && (
                    <div className="mt-4 pt-4 border-t">
                      <Button onClick={startProcessing} className="w-full">
                        Iniciar Processamento
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Tab Processamento */}
          <TabsContent value="processamento" className="space-y-6">
            {processamentos.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <Clock className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-lg font-medium mb-2">Nenhum processamento iniciado</h3>
                  <p className="text-gray-600">
                    Envie arquivos XML na aba "Upload" para começar
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {processamentos.map((proc) => (
                  <Card key={proc.id}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="flex items-center space-x-2">
                          {getStatusIcon(proc.status)}
                          <span>Processamento #{proc.id}</span>
                        </CardTitle>
                        {getStatusBadge(proc.status)}
                      </div>
                      <CardDescription>
                        {proc.total_xmls} arquivos XML • Iniciado em {new Date(proc.inicio).toLocaleString()}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between text-sm mb-2">
                            <span>Progresso</span>
                            <span>{proc.xmls_processados}/{proc.total_xmls} arquivos</span>
                          </div>
                          <Progress value={proc.progresso} className="h-2" />
                        </div>
                        
                        {proc.status === 'completed' && (
                          <Alert>
                            <CheckCircle className="h-4 w-4" />
                            <AlertDescription>
                              Processamento concluído com sucesso! O relatório está disponível para download.
                            </AlertDescription>
                          </Alert>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Tab Resultados */}
          <TabsContent value="resultados" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Download className="h-5 w-5" />
                  <span>Relatórios Gerados</span>
                </CardTitle>
                <CardDescription>
                  Download dos relatórios processados pela plataforma
                </CardDescription>
              </CardHeader>
              <CardContent>
                {processamentos.filter(p => p.status === 'completed').length === 0 ? (
                  <div className="text-center py-8">
                    <FileText className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                    <h3 className="text-lg font-medium mb-2">Nenhum relatório disponível</h3>
                    <p className="text-gray-600">
                      Complete um processamento para gerar relatórios
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {processamentos
                      .filter(p => p.status === 'completed')
                      .map((proc) => (
                        <div key={proc.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center space-x-3">
                            <FileText className="h-5 w-5 text-green-500" />
                            <div>
                              <p className="font-medium">Relatório #{proc.id}</p>
                              <p className="text-sm text-gray-500">
                                {proc.total_xmls} XMLs processados • Concluído em {new Date(proc.fim).toLocaleString()}
                              </p>
                            </div>
                          </div>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => downloadRelatorio(proc.id)}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Download Excel
                          </Button>
                        </div>
                      ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab Correção IA */}
          <TabsContent value="ia" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Brain className="h-5 w-5" />
                  <span>Correção da IA</span>
                </CardTitle>
                <CardDescription>
                  Corrija classificações incorretas para melhorar a precisão da IA
                </CardDescription>
              </CardHeader>
              <CardContent>
                {classificacoes.length === 0 ? (
                  <div className="text-center py-8">
                    <Brain className="h-12 w-12 mx-auto mb-4 text-blue-500" />
                    <h3 className="text-lg font-medium mb-2">Nenhuma classificação disponível</h3>
                    <p className="text-gray-600 mb-4">
                      Processe alguns XMLs para ver as classificações da IA
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {classificacoes.map((classificacao) => (
                      <div key={classificacao.id} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <Badge variant={classificacao.corrigido ? "default" : "secondary"}>
                              {classificacao.corrigido ? "Corrigido" : "Original"}
                            </Badge>
                            <span className="text-sm text-gray-500">
                              NF: {classificacao.nf_numero} | Item: {classificacao.item_numero}
                            </span>
                          </div>
                          {!classificacao.corrigido && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setClassificacaoSelecionada(classificacao)
                                setCorrecaoForm({
                                  finalidade_correta: classificacao.finalidade_ia,
                                  credito_correto: classificacao.credito_pis_cofins_ia
                                })
                                setShowCorrecaoDialog(true)
                              }}
                            >
                              <Edit className="h-4 w-4 mr-2" />
                              Corrigir
                            </Button>
                          )}
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                          <div>
                            <p className="font-medium">NCM: {classificacao.ncm}</p>
                            <p className="text-gray-600">{classificacao.descricao_produto}</p>
                          </div>
                          <div>
                            <p><span className="font-medium">Finalidade:</span> {classificacao.finalidade_ia}</p>
                            <p><span className="font-medium">Crédito PIS/COFINS:</span> {classificacao.credito_pis_cofins_ia}</p>
                            <p><span className="font-medium">Confiança:</span> {(classificacao.confianca * 100).toFixed(1)}%</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Dialog de Correção */}
        <Dialog open={showCorrecaoDialog} onOpenChange={setShowCorrecaoDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Corrigir Classificação da IA</DialogTitle>
              <DialogDescription>
                Corrija a classificação para melhorar a precisão da IA
              </DialogDescription>
            </DialogHeader>
            
            {classificacaoSelecionada && (
              <div className="space-y-4">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <p className="font-medium">NCM: {classificacaoSelecionada.ncm}</p>
                  <p className="text-sm text-gray-600">{classificacaoSelecionada.descricao_produto}</p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="finalidade_correta">Finalidade Correta</Label>
                    <Select 
                      value={correcaoForm.finalidade_correta} 
                      onValueChange={(value) => setCorrecaoForm({...correcaoForm, finalidade_correta: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a finalidade" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Comercialização">Comercialização</SelectItem>
                        <SelectItem value="Uso">Uso</SelectItem>
                        <SelectItem value="Imobilizado">Imobilizado</SelectItem>
                        <SelectItem value="Verificar">Verificar</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="credito_correto">Crédito PIS/COFINS</Label>
                    <Select 
                      value={correcaoForm.credito_correto} 
                      onValueChange={(value) => setCorrecaoForm({...correcaoForm, credito_correto: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o crédito" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Sim">Sim</SelectItem>
                        <SelectItem value="Não">Não</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <Button onClick={corrigirClassificacao}>
                    <Save className="h-4 w-4 mr-2" />
                    Salvar Correção
                  </Button>
                  <Button variant="outline" onClick={() => setShowCorrecaoDialog(false)}>
                    Cancelar
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}

export default App

