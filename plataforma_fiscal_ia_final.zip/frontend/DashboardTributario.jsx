import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function DashboardTributario() {
  const [resposta, setResposta] = useState("");
  const [pergunta, setPergunta] = useState("");

  const handlePerguntar = async () => {
    const res = await fetch("http://localhost:8000/perguntar", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pergunta }),
    });
    const data = await res.json();
    setResposta(data.resposta);
  };

  return (
    <div className="p-6 grid gap-6">
      <h1 className="text-2xl font-bold">Painel Tributário Inteligente</h1>

      <Tabs defaultValue="empresa" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="empresa">Empresa</TabsTrigger>
          <TabsTrigger value="produtos">Produtos</TabsTrigger>
          <TabsTrigger value="chat">Chat IA</TabsTrigger>
        </TabsList>

        <TabsContent value="empresa">
          <Card>
            <CardContent className="grid gap-4 p-4">
              <Input placeholder="CNPJ da empresa" />
              <Input placeholder="Razão Social" />
              <Input placeholder="CNAE principal" />
              <Textarea placeholder="Histórico tributário ou observações" rows={4} />
              <Button>Salvar Empresa</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="produtos">
          <Card>
            <CardContent className="grid gap-4 p-4">
              <Input placeholder="Descrição do produto" />
              <Input placeholder="NCM" />
              <Input placeholder="CFOP" />
              <Button>Cadastrar Produto</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="chat">
          <Card>
            <CardContent className="grid gap-4 p-4">
              <Textarea
                placeholder="Pergunte algo à IA tributária..."
                value={pergunta}
                onChange={(e) => setPergunta(e.target.value)}
              />
              <Button onClick={handlePerguntar}>Perguntar</Button>
              {resposta && (
                <div className="bg-muted p-4 rounded-xl whitespace-pre-wrap">
                  {resposta}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
