# 💻 Plataforma Fiscal IA - Frontend (React + Vite)

Este é o painel visual da plataforma fiscal com abas para cadastro e chat com IA.

## ✅ Tecnologias
- React 18 + Vite
- Tailwind CSS
- shadcn/ui

## ▶️ Execução local

```bash
cd frontend
npm install
npm run dev
```

## 🌐 Deploy na Vercel (grátis)

1. Crie conta em https://vercel.com
2. Crie um repositório com a pasta `frontend/`
3. Em Environment Variables, defina:

```
VITE_API_URL=https://seu-backend.onrender.com
```

4. Acesse sua aplicação em `https://sua-app.vercel.app`