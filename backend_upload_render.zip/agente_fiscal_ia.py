import os
import re
import json
from typing import List

try:
    import fitz  # PyMuPDF
except ImportError:
    fitz = None

class AgenteFiscal:
    def __init__(self, documentos_legislacao: List[str] = None):
        self.documentos = documentos_legislacao or []
        self.base_conhecimento = []
        self._carregar_legislacoes()

    def _carregar_legislacoes(self):
        for doc in self.documentos:
            if os.path.exists(doc):
                texto = self._extrair_texto(doc)
                self.base_conhecimento.append({"arquivo": doc, "conteudo": texto})
            else:
                print(f"[AgenteFiscal] Arquivo não encontrado: {doc}")

    def _extrair_texto(self, caminho):
        if caminho.lower().endswith(".pdf") and fitz:
            try:
                doc = fitz.open(caminho)
                texto = "\n".join([page.get_text() for page in doc])
                doc.close()
                return texto
            except Exception as e:
                print(f"Erro ao ler PDF {caminho}: {e}")
        return f"[SEM CONTEÚDO] {os.path.basename(caminho)}"

    def classificar_produto(self, ncm: str, descricao: str, cfop: str, atividade_empresa: str = "") -> str:
        if not ncm or not descricao:
            return "Verificar"
        if re.match(r"^3|4|5", cfop):
            return "Insumo"
        if any(palavra in descricao.lower() for palavra in ["revenda", "comercializa"]):
            return "Comercialização"
        if atividade_empresa and "industr" in atividade_empresa.lower():
            return "Insumo"
        return "Verificar"

    def verificar_credito_pis_cofins(self, ncm: str, descricao: str, cfop: str, atividade_empresa: str = "") -> str:
        categoria = self.classificar_produto(ncm, descricao, cfop, atividade_empresa)
        if categoria == "Comercialização" and ncm.startswith("3002"):
            return "Sim"
        if categoria == "Insumo" and any(x in descricao.lower() for x in ["matéria-prima", "embalagem"]):
            return "Sim"
        return "Não"

    def mostrar_base(self):
        return [doc["arquivo"] for doc in self.base_conhecimento]

def aplicar_classificacao_ia(item_info, agente_fiscal, atividade_empresa=""):
    ncm = item_info.get("ncm_limpo", "")
    descricao = item_info.get("descricao", "")
    cfop = item_info.get("cfop", "")

    categoria = agente_fiscal.classificar_produto(ncm, descricao, cfop, atividade_empresa)
    credito = agente_fiscal.verificar_credito_pis_cofins(ncm, descricao, cfop, atividade_empresa)

    item_info["categoria"] = categoria
    item_info["credito_elegivel"] = credito

    return item_info
